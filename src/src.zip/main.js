import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
// import { firebaseConfig } from "./util/dbConfig";
// import { initializeApp } from "firebase/app";
// import { getFirestore, doc, getDoc , } from "firebase/firestore";
import {  getPlaceList,getPlace,addplace,deletePlace,updatePlace} from "./model/place.js"
// import { deleteDoc } from 'firebase/firestore'

// const firebaseApp = initializeApp(firebaseConfig);
// const dbFirestore = getFirestore(firebaseApp);

// async function getDocument() {
//     const docRef = doc(dbFirestore, "youtest", "1")
//     const docSnap = await getDoc(docRef);
//     console.log(docSnap.data())
// }

// getDocument()

getPlaceList().then((res)=>{
    console.log(2,res);
});

getPlace(1).then((res)=>{//id(2)為資料表，第一個場所資料
    console.log(26,res);
});
var sendd = {
    id: 10,
    name: "8",
    Status:"8",
    address:"8"    
}

addplace(sendd).then((res)=>{
    // console.log(35,sendd)
    console.log(30,res);
});
var test=false
if (test){
deletePlace(4).then((res)=>{
    console.log(42,res);
});
}

var neww = {
    id: 10,
    newid:4,
    name: "update",
    Status:"update",
    address:"update"    
}

updatePlace(neww).then((res)=>{
    console.log(55,res);
});


createApp(App).use(store).use(router).mount('#app')
