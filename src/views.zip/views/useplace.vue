<template>
  <div class="place">
    <!-- <img alt="Vue logo" src="../assets/logo.png" /> -->
    <p>id:{{ placedata.pId }}</p>
    <p>name:{{ placedata.name }}</p>
    <p>cellphone:{{ placedata.cellphone }}</p>
    {{ placedata }}
  </div>
</template>
<script>
import { onMounted, reactive } from "vue";
import { getPlace } from "../model/place.js";
import { useRoute } from "vue-router";

export default {
  name: "place",
  setup() {
    const Route = useRoute();
    let idd = "";
    onMounted(async () => {
      const id = Route.params.id;
      idd = id;
      console.log(20, id);
      await getPlace(idd).then((val) => {
        console.log(22, val);
        Object.assign(placedata, val);
      });
    });
    const placedata = reactive({});
    return { placedata };
  },
};
</script>
