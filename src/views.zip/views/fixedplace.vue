<template>
<h2 class="title3">固定場所-場所資料</h2> 
<a href="javascript:void(0)"
    onclick="document.getElementById('lightf').style.display='block';document.getElementById('fadef').style.display='block'"
    ><button class="comment-f">i</button></a>
  <div id="lightf" class="explanationf">
    <pre>
    註:聯絡地址為您收取出入口裝置的地址，
       請務必填寫有人收件的地址。
    </pre>
     <a
      href="javascript:void(0)"
      onclick="document.getElementById('lightf').style.display='none';document.getElementById('fadef').style.display='none'"
      class="xf"
      >X</a>
  </div>
<form class="name3">
    <label for="new-todo-input">
    場所名稱:
    </label>
     <input 
      type="text" name="name"           autocomplete="off"   v-model="formObj.name"/>
</form> 
<form class="leaderid3">
    <label for="new-todo-input">
    場所負責人身分證:
    </label>
     <input 
      type="text" name="leaderid"           autocomplete="off"   v-model="formObj.leaderid"/>
</form>
<form class="cellphone3">
    <label for="new-todo-input">
    場所負責人手機:
    </label>
     <input 
      type="text" name="cellphone"           autocomplete="off"   v-model="formObj.cellphone"/>
</form>
<form class="telephone3">
    <label for="new-todo-input">
    場所電話:
    </label>
     <input 
      type="text" name="telephone"           autocomplete="off"   v-model="formObj.telephone"/>
</form>
<form class="address3">
    <label for="new-todo-input">
    場所地址:
    </label>
     <input 
      type="text" name="address"           autocomplete="off"   v-model="formObj.address"/>
</form>
<form class="con_address3">
    <label for="new-todo-input">
    聯絡地址:
    </label>
     <input 
      type="text" name="con_address"           autocomplete="off"   v-model="formObj.con_address"/>
</form>
<form class="taxadd">
  <label for="new-todo-input">
    統一編號:
    </label>
     <input 
      type="text" name="tax"           autocomplete="off"   v-model="formObj.tax" class="taxwidth" placeholder="法人請輸入統編，非法人請填null" /><br>
      <input 
      type="text" name="type"           autocomplete="off"  value="固定場所" class="taxwidth" readonly />
</form>
<div>
   <button class="send3" type="submit" value="/Homenext.vue" @click="onSubmit($event)" onclick="location.href='/Homenext'" >送出</button>
</div>
</template>
<style>
.title3{
  position: absolute;
  top: 60px;
  left: 100px;
}
.name3{
  position: absolute;
  top:140px;
  left: 60px;
}
.leaderid3{
  position: absolute;
  top:180px;
  left: 60px;
}
.cellphone3{
  position: absolute;
  top:220px;
  left: 60px; 
}
.telephone3{
  position: absolute;
  top:260px;
  left: 60px; 
}
.address3{
  position: absolute;
  top:300px;
  left: 60px; 
}
.con_address3{
  position: absolute;
  top:340px;
  left: 60px; 
}
.send3{
  position: absolute;
  top: 390px;
  right: 100px;
  width:50px ;
  height:20px;
  font-size: 10px;
}
.taxadd{
  position: absolute;
  top:380px;
  left: 60px; 
}
.taxwidth{
  width: 250px;
}

.comment-f {
  border: radius 50%;
  font-size: 20px;
  position: absolute;
  top: 13%;
  right: 30%;
  border-radius: 50%;
  width: 25px;
  height: 25px;
}

.explanationf {
  display: none;
  position: absolute;
  padding-top: 3%;
  padding-right: 8%;
  top: 40%;
  left: 10%;
  border: 1px solid rgba(172, 184, 218, 0.548);
  border-radius: 10px;
  background-color: white;
  z-index: 1002;
  overflow: auto;
  text-align: center;
  font-size: 20px;
}
.xf {
  position: absolute;
  top: 5%;
  right: 5%;
  text-decoration: none;
  color: black;
}
</style>

// <script>
import {/*getPlaceList,*/addplace}from"../model/place"
// import {onMounted} from "vue";
var sendd={
  name:"",
  leaderid:"",
  cellphone:"",
  telephone:"",
  address:"",
  con_address:"",
  tax:"",
  type:'',
  carnumber:"",
}
export default{
  data(){
    return{
      formObj:{
        name:'',
        leaderid:'',
        cellphone:'',
        telephone:'',
        address:'',
        con_address:'',
        tax:'',
      }
    }
  },
  methods:{
    onSubmit(event){
      event.preventDefault();
      let formData = JSON.stringify(this.formObj);
      console.log(191,formData);
      sendd.name=this.formObj.name;
      sendd.leaderid=this.formObj.leaderid;
      sendd.cellphone=this.formObj.cellphone;
      sendd.telephone=this.formObj.telephone;
      sendd.address=this.formObj.address;
      sendd.con_address=this.formObj.con_address;
      sendd.tax=this.formObj.tax
      sendd.type="固定場所"
      addplace(sendd)
      console.log(88,sendd);
    }
  },
  // setup(){
  //   onMounted(async()=>{
  //   await addplace(sendd).then((res)=>{
  //     console.log(333,res);
  //   });
  //   });
    
  // }
}

</script>