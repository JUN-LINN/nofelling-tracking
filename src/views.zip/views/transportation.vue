<template>
<h2 class="title5">交通工具-場所資料</h2> 
<a href="javascript:void(0)"
    onclick="document.getElementById('lightt').style.display='block';document.getElementById('fadet').style.display='block'"
    ><button class="comment-t">i</button></a>
  <div id="lightt" class="explanationt">
    <pre>
    註:聯絡地址為您收取出入口裝置的地址，
       請務必填寫有人收件的地址。
    </pre>
     <a
      href="javascript:void(0)"
      onclick="document.getElementById('lightt').style.display='none';document.getElementById('fadet').style.display='none'"
      class="xt"
      >X</a>
  </div>
<form class="pid5">
    <label for="new-todo-input">
    場所名稱:
    </label>
     <input 
      type="text" name="name"           autocomplete="off"   v-model="formObj.name"/>
</form> 
<form class="leaderid5">
    <label for="new-todo-input">
    場所負責人身分證:
    </label>
     <input 
      type="text" name="leaderid"           autocomplete="off"   v-model="formObj.leaderid"/>
</form>
<form class="cellphone5">
    <label for="new-todo-input">
    場所負責人手機:
    </label>
     <input 
      type="text" name="cellphone"           autocomplete="off"   v-model="formObj.cellphone"/>
</form>
<form class="telephone5">
    <label for="new-todo-input">
    場所電話:
    </label>
     <input 
      type="text" name="telephone"           autocomplete="off"   v-model="formObj.telephone"/>
</form>
<form class="carnumber5">
    <label for="new-todo-input">
    車牌/編號:
    </label>
     <input 
      type="text" name="carnumber"           autocomplete="off"   v-model="formObj.carnumber"/>
</form>
<form class="con_address5">
    <label for="new-todo-input">
    聯絡地址:
    </label>
     <input 
      type="text" name="con_address"           autocomplete="off"   v-model="formObj.con_address"/>
</form>
<form class="taxadd4">
  <label for="new-todo-input">
    統一編號:
    </label>
     <input 
      type="text" name="tax"           autocomplete="off"   v-model="formObj.tax" class="taxwidth4" placeholder="法人請輸入統編，非法人請填null" />
      <br>
      <input 
      type="text" name="type"           autocomplete="off"  value="交通工具" class="taxwidth" readonly />
</form>
<div>
  <button class="send5"  value="/Homenext.vue" @click="onSubmit($event)" onclick="location.href='/Homenext'" >送出</button>
</div>
</template>
<style>
.title5{
  position: absolute;
  top: 60px;
  left: 100px;
}
.pid5{
  position: absolute;
  top:140px;
  left: 60px;
}
.leaderid5{
  position: absolute;
  top:180px;
  left: 60px;
}
.cellphone5{
  position: absolute;
  top:220px;
  left: 60px; 
}
.telephone5{
  position: absolute;
  top:260px;
  left: 60px; 
}
.carnumber5{
  position: absolute;
  top:300px;
  left: 60px; 
}
.con_address5{
  position: absolute;
  top:340px;
  left: 60px; 
}
.send5{
  position: absolute;
  top: 390px;
  right:100px;
  width:50px ;
  height:20px;
  font-size: 10px;
}
.comment-t {
  border: radius 50%;
  font-size: 20px;
  position: absolute;
  top: 13%;
  right: 30%;
  border-radius: 50%;
  width: 25px;
  height: 25px;
}
.taxadd4{
  position: absolute;
  top:380px;
  left: 60px; 
}
.taxwidth4{
  width: 250px;
}
.explanationt {
  display: none;
  position: absolute;
  padding-top: 3%;
  padding-right: 8%;
  top: 40%;
  left: 10%;
  border: 1px solid rgba(172, 184, 218, 0.548);
  border-radius: 10px;
  background-color: white;
  z-index: 1002;
  overflow: auto;
  text-align: center;
  font-size: 20px;
}
.xt {
  position: absolute;
  top: 5%;
  right: 5%;
  text-decoration: none;
  color: black;
}
</style>

// <script>
import {/*getPlaceList,*/addplace}from"../model/place"
// import {onMounted} from "vue";
var sendd={
  name:"",
  leaderid:"",
  cellphone:"",
  telephone:"",
  address:"",
  con_address:"",
  tax:"",
  type:'',
  carnumber:"",
}
export default{
  data(){
    return{
      formObj:{
        name:'',
        leaderid:'',
        cellphone:'',
        telephone:'',
        carnumber:'',
        address:'',
        tax:'',
      }
    }
  },
  methods:{
    onSubmit(event){
      event.preventDefault();
      let formData = JSON.stringify(this.formObj);
      console.log(191,formData);
      sendd.name=this.formObj.name;
      sendd.leaderid=this.formObj.leaderid;
      sendd.cellphone=this.formObj.cellphone;
      sendd.telephone=this.formObj.telephone;
      sendd.carnumber=this.formObj.carnumber;
      sendd.address=this.formObj.address;
      sendd.tax=this.formObj.tax
      sendd.type="交通工具"
      addplace(sendd)
      console.log(88,sendd);
    }
  },
  // setup(){
  //   onMounted(async()=>{
  //   await addplace(sendd).then((res)=>{
  //     console.log(333,res);
  //   });
  //   });
    
  // }
}
</script>