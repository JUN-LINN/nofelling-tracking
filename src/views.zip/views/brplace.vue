<template>
<h2 class="title1">場所出入口裝置註冊</h2>
    <div class="bluetooth1">
      選擇需要裝置數量:
  <select>
    <option disabled value="">請選擇</option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
    <option value="7">7</option>
    <option value="8">8</option>
    <option value="9">9</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
    <option value="13">13</option>
    <option value="14">14</option>
    <option value="15">15</option>
    <option value="16">16</option>
    <option value="17">17</option>
    <option value="18">18</option>
    <option value="19">19</option>
    <option value="20">20</option>
  </select>

</div>
<div>
<form class="delivery1">
    <label for="new-todo-input">
    寄送地址:
    </label>
     <input 
      type="text"/>
</form>
</div>
<div>
  <button class="home1" v-on:click="sendit">送出</button>
</div>

</template>
<style>
.title1{
  position: absolute;
  top: 100px;
  left: 90px;
  font-size: 25px;
}
.bluetooth1{
  position: absolute;
  top: 180px;
  left: 25%;
}
.delivery1{
  position: absolute;
  top: 230px;
  left: 23%;
}
.home1{
  position: absolute;
  top: 290px;
  left: 70%;
  border-radius: 40%;
  width:55px ;
  height:35px;
  font-size: 10px;
}
</style>

// <script>

// import{
//     updatePlace
//     // getPlace
//   }from"../model/place.js";
// import {onMounted,ref } from "vue";


// export default {


//   data() {
//     return {
//       msg: "",
//     };
//   },
//    setup() {
//     onMounted(async()=>{
//       await data().then((res) => {
//         console.log(32,res);//32代表第幾行
//         Object.assign(placeData.value,res);
//       });
//     });
//     const placeData = ref([]);
//     // async function goToPlacePage(pId){
//     //   console.log(41,pId)
//     //   // await getPlace(id).then((res)=>{
//     //     // console.log(44,res);
//     //   // })
//     // }
//     // return {placeData,goToPlacePage};
//   },
  
// };
</script>