
<template>
  <div class="place register">
    <div v-for ="(data,index) in placeData"
      :key ="index" style="margin-bottom:5%"
      @click="goToPlacePage(data.mname)">
      <p>附屬場所id:{{data.mid}}</p> <br>
      <p>場所名稱:{{data.mname}}</p>
      {{index}}
    </div>
    
   
  </div>
  
</template>

<script>
// @ is an alias to /src
 import{ useRouter }from "vue-router"
import{
    getPlaceList,
    getPlace
  }from"../model/miniplace.js";
import {onMounted,ref } from "vue";

export default {
  name: "place register",
  // components: {
  //   HelloWorld,
  // },  
 setup() {
    onMounted(async () => {
      await getPlaceList().then((res) => {
        console.log(31, res);
        Object.assign(placeData.value, res);
      });
      console.log(29, placeData.value);
    });
    const placeData = ref([]);
    const Router = useRouter();
    async function goToPlacePage(mid) {
      console.log(38, mid);
      var b=mid
      Router.push({ name: "usemplace", params: { mid: b } });
      await getPlace(mid).then((res) => {
        console.log(34, res);
      });
    }

    return { placeData, goToPlacePage };
  },
};
</script>
