<template>
<h2 class="title7">附屬場所-場所資料</h2> 
      <a href="javascript:void(0)"
    onclick="document.getElementById('lightmini').style.display='block';document.getElementById('fademini').style.display='block'"
    ><button class="comment-mini">i</button></a>
  <div id="lightmini" class="explanationmini">
    <pre>
    註:聯絡地址為您收取出入口裝置的地址，
       請務必填寫有人收件的地址。
    </pre>
     <a
      href="javascript:void(0)"
      onclick="document.getElementById('lightmini').style.display='none';document.getElementById('fademini').style.display='none'"
      class="xmini"
      >X</a>
  </div>
<form class="pid7">
    <label for="new-todo-input">
    場所ID:
    </label>
     <input 
      type="text" name="id"           autocomplete="off"   v-model="formObj.id"/>
</form> 
<form class="name7">
    <label for="new-todo-input">
    附屬場所名稱:
    </label>
     <input 
      type="text" name="mname"           autocomplete="off"   v-model="formObj.mname"/>
</form> 
<form class="leaderid7">
    <label for="new-todo-input">
    附屬場所負責人身分證:
    </label>
     <input 
      type="text" name="mleaderid"           autocomplete="off"   v-model="formObj.mleaderid"/>
</form>
<form class="cellphone7">
    <label for="new-todo-input">
    附屬場所負責人手機:
    </label>
     <input 
      type="text" name="mcellphone"           autocomplete="off"   v-model="formObj.mcellphone"/>
</form>
<form class="telephone7">
    <label for="new-todo-input">
    附屬場所電話:
    </label>
     <input 
      type="text" name="mtelephone"           autocomplete="off"   v-model="formObj.mtelephone"/>
</form>

<form class="con_address7">
    <label for="new-todo-input">
    附屬場所聯絡地址:
    </label>
     <input 
      type="text" name="mcon_address"           autocomplete="off"   v-model="formObj.mcon_address"/>
</form>
<form class="taxadd5">
  <label for="new-todo-input">
    統一編號:
    </label>
     <input 
      type="text" name="mtax" autocomplete="off" v-model="formObj.mtax" class="taxwidth5" placeholder="法人請輸入統編，非法人請填null" />
</form>
<div>
  <button class="send3" type="submit" value="/miniHome.vue" @click="onSubmit($event)" onclick="location.href='/miniHome'" >送出</button>
</div>
</template>
<style>
.title7{
  position: absolute;
  top: 60px;
  left: 100px;
}
.pid7{
  position: absolute;
  top:140px;
  left: 50px;
}
.name7{
  position: absolute;
  top:180px;
  left: 50px;
}
.leaderid7{
  position: absolute;
  top:220px;
  left: 50px; 
}
.cellphone7{
  position: absolute;
  top:260px;
  left: 50px; 
}
.telephone7{
  position: absolute;
  top:300px;
  left: 50px; 
}
.con_address7{
   position: absolute;
  top:340px;
  left: 50px; 
}
.send7{
  position: absolute;
  top: 430px;
  right: 100px;
  width:50px ;
  height:20px;
  font-size: 10px;
}
.comment-mini {
  border: radius 50%;
  font-size: 20px;
  position: absolute;
  top: 13%;
  right: 25%;
  border-radius: 50%;
  width: 25px;
  height: 25px;
}

.explanationmini {
  display: none;
  position: absolute;
  padding-top: 3%;
  padding-right: 8%;
  top: 40%;
  left: 10%;
  border: 1px solid rgba(172, 184, 218, 0.548);
  border-radius: 10px;
  background-color: white;
  z-index: 1002;
  overflow: auto;
  text-align: center;
  font-size: 20px;
}
.xmini {
  position: absolute;
  top: 5%;
  right: 5%;
  text-decoration: none;
  color: black;
}
.taxadd5{
  position: absolute;
  top:380px;
  left: 50px; 
}
.taxwidth5{
  width: 250px;
}

</style>

// <script>

import {/*getPlaceList,*/addminiplace}from"../model/miniplace"
 //import {onMounted} from "vue";
var sendd={
  id:"",
  mname:'',
  mleaderid:"",
  mcellphone:"",
  telephone:"",
  mcon_address:"",
  mtax:"",
  mid:""
}
export default{
  data(){
    return{
      formObj:{
        id:'',
        mname:'',
        mleaderid:'',
        mcellphone:'',
        mtelephone:'',
        mcon_address:'',
        mtax:''
      }
    }
  },
  methods:{
    onSubmit(event){
      event.preventDefault();
      let formData = JSON.stringify(this.formObj);
      console.log(formData);
      sendd.mid=this.formobj.mid;
      sendd.id=this.formObj.id;
      sendd.mname=this.formObj.mname;
      sendd.mleaderid=this.formObj.mleaderid;
      sendd.mcellphone=this.formObj.mcellphone;
      sendd.mtelephone=this.formObj.mtelephone;
      sendd.mcon_address=this.formObj.mcon_address;
      sendd.mtax=this.formObj.mtax;
      addminiplace(sendd)
      console.log(88,sendd);
    }
  },
   //setup(){
     //onMounted(async()=>{
     //await addplace(sendd).then((res)=>{
    //console.log(333,res);
    //});
     //});
    
   //}
}
</script>