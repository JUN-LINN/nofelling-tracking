<template>
<h2 class="title9">附屬場所出入口裝置設定</h2>
   <div>
<form class="bid9">
    <label for="new-todo-input">
    輸入出入口裝置ID:
    </label>
     <input 
      type="text"/>
</form>
<form class="gate9">
    <label for="new-todo-input">
    出入口名稱:
    </label>
     <input 
      type="text"/>
</form>
</div>

<div>
  <button class="update9" v-on:click="update">更新</button>
</div>
</template>
<style>
.title9{
  position: absolute;
  top: 160px;
  left: 70px;
  font-size: 25px;
}
.bid9{
  position: absolute;
  top: 240px;
  left: 20%;
}
.gate9{
  position: absolute;
  top: 290px;
  left: 20%;
}
.home9{
  position: absolute;
  top: 350px;
  left: 70%;
  border-radius: 40%;
  width:55px ;
  height:35px;
  font-size: 10px;
}
.update9{
  position: absolute;
  top: 350px;
  left: 50%;
  border-radius: 40%;
  width:55px ;
  height:35px;
  font-size: 10px;
}
</style>

// <script>

// import{
//     updatePlace
//     // getPlace
//   }from"../model/place.js";
// import {onMounted,ref } from "vue";


// export default {


//   data() {
//     return {
//       msg: "",
//     };
//   },
//    setup() {
//     onMounted(async()=>{
//       await data().then((res) => {
//         console.log(32,res);//32代表第幾行
//         Object.assign(placeData.value,res);
//       });
//     });
//     const placeData = ref([]);
//     // async function goToPlacePage(pId){
//     //   console.log(41,pId)
//     //   // await getPlace(id).then((res)=>{
//     //     // console.log(44,res);
//     //   // })
//     // }
//     // return {placeData,goToPlacePage};
//   },
  
// };
</script>