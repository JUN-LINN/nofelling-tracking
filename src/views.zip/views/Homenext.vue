
<template>
  <div class="place register">
    <div v-for ="(data,index) in placeData"
      :key ="index" style="margin-bottom:5%"
      @click="goToPlacePage(data.name)">
      <p>場所id:{{data.id}}</p> <br>
      <p>場所名稱:{{data.name}}</p>
      {{index}}
    </div>
    
   
  </div>
  
</template>

<script>
// @ is an alias to /src
 import{ useRouter }from "vue-router"
import{
    getPlaceList,
    getPlace
  }from"../model/place.js";
import {onMounted,ref } from "vue";

export default {
  name: "place register",
  // components: {
  //   HelloWorld,
  // },  
 setup() {
    onMounted(async () => {
      await getPlaceList().then((res) => {
        console.log(31, res);
        Object.assign(placeData.value, res);
      });
      console.log(29, placeData.value);
    });
    const placeData = ref([]);
    const Router = useRouter();
    async function goToPlacePage(id) {
      console.log(38, id);
      var a=id
      Router.push({ name: "useplace", params: { id: a } });
      await getPlace(id).then((res) => {
        console.log(34, res);
      });
    }

    return { placeData, goToPlacePage };
  },
};
</script>
